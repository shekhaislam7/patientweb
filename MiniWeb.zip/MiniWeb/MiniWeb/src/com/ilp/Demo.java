package com.ilp;

import java.sql.Connection;

import com.ilp.utilities.DbCon;


public class Demo extends DbCon{
	public static void main(String arg[]) {
		
 
	}
	
	

}
