package com.ilp.services;

import java.util.ArrayList;

import com.ilp.beans.Patient;

public class PatientService implements ServiceInterface<Patient> {

	@Override
	public ArrayList<Patient> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Patient obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Patient save(Patient obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
