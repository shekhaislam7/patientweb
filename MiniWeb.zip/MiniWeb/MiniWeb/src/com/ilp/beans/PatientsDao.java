package com.ilp.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

import com.ilp.dal.DaoInterface;
import com.ilp.utilities.DbCon;

public class PatientsDao extends DbCon implements DaoInterface<Patient>  {
	

	@Override
	public ArrayList<Patient> findAll() throws Exception{
		PreparedStatement pstmt = null;
		Connection connection = null;
		ResultSet rs = null;
		String query = null;
		ArrayList<Patient> arrAllPatients = null;
		
		try {
			connection = DbCon.getConnection();
			
				query = "select sequnceid, first_name, last_name, age, gender , location, email  from bs71234_patients ";

			pstmt = connection.prepareStatement(query);
			rs = (ResultSet) pstmt.executeQuery();

			if (rs != null) {
				arrAllPatients = new ArrayList<Patient>();
				while (rs.next()) {
					Patient mPatient = new Patient();
					mPatient.setFirstName(rs.getString("first_name")); 
					mPatient.setId(rs.getString("sequnceid")); 
					mPatient.setLastName(rs.getString("last_name")); 
					mPatient.setAge(rs.getString("age")); 
					mPatient.setEmail(rs.getString("email")); 
					mPatient.setGender(rs.getString("gender")); 
					mPatient.setLocation(rs.getString("location")); 
					arrAllPatients.add(mPatient);
				

				} 
			}
			
			pstmt.close();
			System.out.println("record selected to the database");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbCon.closeConnection();
			
		}
		
		return arrAllPatients;
	}

	@Override
	public Patient findById(int id) {
		PreparedStatement pstmt = null;
		Connection connection = null;
		ResultSet rs = null;
		String query = null;
		Patient mPatient = null;
		try {
			connection = DbCon.getConnection();
			
				query = "select first_name, last_name, age, gender , location  from bs71234_patients where patient_idnumber = ?";

			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, id);
			rs = (ResultSet) pstmt.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					mPatient = new Patient();
					mPatient.setFirstName(rs.getString("first_name")); 
					mPatient.setLastName(rs.getString("last_name")); 
					mPatient.setAge(rs.getString("age")); 
					mPatient.setEmail(rs.getString("gender")); 
					mPatient.setLocation(rs.getString("location")); 
				

				}
			}
			
			pstmt.close();
			System.out.println("record updated to the database");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbCon.closeConnection();
			
		}
		
		return mPatient;
	}

	@Override
	public void update(Patient obj) {
		String query = null;
		PreparedStatement pstmt = null;
		Connection connection = null;
		try {
			connection = DbCon.getConnection();
			connection.setAutoCommit(false);
			
			 query = "update bs71234_patients set first_name = ? ,last_name = ?, email = ?, age = ?, gender =?, location = ?   where sequnceid = ? "; 

			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, obj.getFirstName());
			pstmt.setString(2, obj.getLastName());
			pstmt.setString(3, obj.getEmail());
			pstmt.setString(4, obj.getAge());
			pstmt.setString(5, obj.getGender());
			pstmt.setString(6, obj.getLocation());
			pstmt.setString(7, obj.getId());
			
			
			try {
				pstmt.executeUpdate();
				}catch(Exception e) {
					throw new Exception (" failed query "+query+" "+e.getMessage());
				}

			pstmt.close();
			connection.commit();
			System.out.println("record updated to the database");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbCon.closeConnection();
		}
		
	}

	@Override
	public Patient save(Patient obj) {
		String query = null;
		PreparedStatement pstmt = null;
		Connection connection = null;
		try {
			connection = DbCon.getConnection();
			connection.setAutoCommit(false);
			
			
			/*CREATE TABLE `bs71234_patients` (
	`first_name` VARCHAR(50) NOT NULL,
	`last_name` VARCHAR(50) NOT NULL,
	`age` VARCHAR(50) NOT NULL,
	`gender` CHAR(10) NOT NULL,
	`email` VARCHAR(50) NOT NULL DEFAULT '',
	`location` VARCHAR(50) NOT NULL
)

CREATE SEQUENCE BS71234_PATIENT_ID_SEQ2 MINVALUE 1 START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER BS71234_PATIENT_TR
BEFORE INSERT
 ON bs71234_patients REFERENCING NEW as New OLD as Old
 FOR EACH ROW
 WHEN (New.sequnceid is null)
 BEGIN
 :new.sequnceid := BS71234_PATIENT_ID_SEQ2.nextval;
 END;

ALTER TRIGGER BS71234_PATIENT_TR ENABLE;

commit;
;
*/

			query = "insert into bs71234_patients (first_name,  last_name,  age, gender,  email, location, comments, sequnceid ) "
					+ "values (?, ?, ?, ?, ?, ?, ?, ?) ";
			                 //1  2  3  4  5  6  7 8
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, obj.getFirstName());
			pstmt.setString(2, obj.getLastName());
			pstmt.setString(3, obj.getAge());
			pstmt.setString(4, obj.getGender());
			pstmt.setString(5, obj.getEmail());
			pstmt.setString(6, obj.getLocation());
			pstmt.setString(7, obj.getComment()); 
			pstmt.setString(8, RandomStringUtils.random(10, false, true));
			System.out.println("first Name "+obj.getFirstName());
			
			try {
				pstmt.executeUpdate();
				}catch(Exception e) {
					throw new Exception (" failed query "+query+" "+e.getMessage());
				}		

			pstmt.close();
			connection.commit();
			System.out.println("record added to the database");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbCon.closeConnection();
		}

		return null;
	}

	@Override
	public void delete(int id) {		
		String query = null;
		PreparedStatement pstmt = null;
		Connection connection = null;
		try {
			connection = DbCon.getConnection();
			connection.setAutoCommit(false);
			
			 query = "delete from  bs71234_patients where sequnceid = ? "; 

			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1,id);
			
			try {
				pstmt.executeUpdate();
				}catch(Exception e) {
					throw new Exception (" failed query "+query+" "+e.getMessage());
				}	
			
			pstmt.close(); 
			connection.commit();
			System.out.println("record with id "+id+ " deleted from the database");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbCon.closeConnection();
		}
	}

}
