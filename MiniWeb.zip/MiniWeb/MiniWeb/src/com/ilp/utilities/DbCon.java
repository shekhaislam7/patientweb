package com.ilp.utilities;

import java.sql.Connection;
import java.sql.DriverManager;


public class DbCon {
	private static Connection con = null;
	// If this is a remote database, 
	// change localhost to the IP address of the remove server
	// change the username and password to the one for your database
	//com.mysql.cj.jdbc.Driver
	//private static final String URL = "jdbc:mysql://localhost/patients?characterEncoding=UTF-8&verifyServerCertificate=false&useSSL=true&requireSSL=false&rewriteBatchedStatements=true&zeroDateTimeBehavior=convertToNull";

	private static final String URL ="jdbc:oracle:thin:@localhost:1521:XE";//jdbc:oracle:thin:@localhost:1521:xe
	private static final String USERNAME = "ILP";
	private static final String PASSWORD = "ILP";
	
	public static void main(String [] arg) throws Exception {
		getConnection();
		
	}
	
	public static Connection getConnection() {
		if(con==null){
				try {
				System.out.println("Connecting database...");
				Class.forName("oracle.jdbc.driver.OracleDriver");  

				con = DriverManager.getConnection(URL, USERNAME,PASSWORD);
				System.out.println("Connected...");

				}catch(Exception e){
				e.printStackTrace();
				}
			}
			return con;
		}
	public static void closeConnection(){
		try{
			System.out.println("clossing connection...");

			if(con != null && !con.isClosed()){
			   con.close();
			}
			   con = null;
		}catch(Exception e)
	    {
	  e.printStackTrace();
	}
  }


}
