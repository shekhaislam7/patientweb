package com.ilp.dal;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ilp.beans.Patient;
import com.ilp.beans.PatientsDao;

public class PatientImpl  {
	
	public  void insertRecord( HttpServletRequest request, HttpServletResponse response, ServletContext ctx) {
		try {
			Patient mPetient = new Patient();
			String firstName = null; String lastName = null; String age = null; String gender = null;
			String location = null; String email = null; String comment = null;
			if (request.getParameter("firstname") != null) firstName = request.getParameter("firstname").trim();
			if (request.getParameter("lastname") != null) lastName = request.getParameter("lastname").trim();
			if (request.getParameter("age") != null) age = request.getParameter("age").trim();
			if (request.getParameter("hdngender") != null) gender = request.getParameter("hdngender").trim();
			if (request.getParameter("hdnlocation") != null) location = request.getParameter("hdnlocation").trim();
			if (request.getParameter("email_address") != null) email = request.getParameter("email_address").trim();
			if (request.getParameter("comment") != null) comment = request.getParameter("comment").trim();
			
			
			System.out.println("record firstName "+ firstName +" lastName "+ lastName +" age "+age +" gender "+gender+" location "+ location
					+ " email "+ email  + " comment "+ comment);

			mPetient.setFirstName(firstName);
			mPetient.setLastName(lastName);
			mPetient.setAge(age);
			mPetient.setGender(gender);
			mPetient.setLocation(location);
			mPetient.setEmail(email);
			mPetient.setComment(comment);
			
						
			PatientsDao patientsDao = new PatientsDao();
			
			patientsDao.save(mPetient);
			request.setAttribute("arrAllPatients", patientsDao.findAll());
			System.out.println("Page selected forwading after insert");
			ctx.getRequestDispatcher("/viewRecords.jsp").forward(request, response);
			
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			
		}finally {
			
			
		}
	
	}

	public  void updateRecord( HttpServletRequest request, HttpServletResponse response, ServletContext ctx) {
		try {
			Patient mPetient = new Patient();
			String firstName = null; String lastName = null; String age = null; String gender = null;
			String location = null; String email = null; String patientId = null;
			if (request.getParameter("fname") != null) firstName = request.getParameter("fname").trim();
			if (request.getParameter("lname") != null) lastName = request.getParameter("lname").trim();
			if (request.getParameter("age") != null) age = request.getParameter("age").trim();
			if (request.getParameter("hdngender") != null) gender = request.getParameter("hdngender").trim();
			if (request.getParameter("hdnlocation") != null) location = request.getParameter("hdnlocation").trim();
			if (request.getParameter("email") != null) email = request.getParameter("email").trim();
			if (request.getParameter("sysid") != null) patientId = request.getParameter("sysid").trim();
			
			mPetient.setFirstName(firstName);
			mPetient.setLastName(lastName);
			mPetient.setAge(age);
			mPetient.setGender(gender);
			mPetient.setLocation(location);
			mPetient.setEmail(email);
			mPetient.setId(patientId);
			
						
			PatientsDao patientsDao = new PatientsDao();
			
			patientsDao.update(mPetient);
			request.setAttribute("arrAllPatients", patientsDao.findAll());
			System.out.println("Page selected forwading");
			ctx.getRequestDispatcher("/viewRecords.jsp").forward(request, response);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
	
	}

	public  void selectRecord( HttpServletRequest request, HttpServletResponse response, ServletContext ctx) {
		try {
			Patient mPetient = null;
			String patientId = null; 
			if (request.getParameter("patientid") != null) patientId = request.getParameter("patientid").trim();
		
						
			PatientsDao patientsDao = new PatientsDao();
			mPetient =  patientsDao.findById(Integer.valueOf(patientId));
			request.setAttribute("records", mPetient);
			
			ctx.getRequestDispatcher("/viewRecords.jsp").forward(request, response);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			
		}finally {
			
			
		}
	
	}
	
	public  void selectRecords( HttpServletRequest request, HttpServletResponse response, ServletContext ctx) {
		try {
			String patientId = null; 
								
			PatientsDao patientsDao = new PatientsDao();
			ArrayList< Patient> AllPatientRecords =  patientsDao.findAll();
			request.setAttribute("arrAllPatients", AllPatientRecords);
			
			ctx.getRequestDispatcher("/viewRecords.jsp").forward(request, response);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
	
	}
	
	public  void deleteRecord( HttpServletRequest request, HttpServletResponse response, ServletContext ctx) {
		try {
			String patientId = null; 
			if (request.getParameter("hdnid") != null) patientId = request.getParameter("hdnid").trim();
									
			PatientsDao patientsDao = new PatientsDao();
			
			patientsDao.delete(Integer.valueOf(patientId));
			System.out.println("After deleteing record");

			ArrayList< Patient> AllPatientRecords =  patientsDao.findAll();
			request.setAttribute("arrAllPatients", AllPatientRecords);
			
			ctx.getRequestDispatcher("/viewRecords.jsp").forward(request, response);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
	
	}
	
	
}
